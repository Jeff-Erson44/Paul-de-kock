<?php

// localhost:1080

// mail('moi@free.fr','test de mail','Le message de mon mail');

if (!empty($_POST)) {

    // controles à faire : que tous les champs sont remplis, format du mail etc...

    $headers[] = 'MIME-Version:1.0';
    $headers[] = 'Content-type:text/html; charset=iso-8859-1';
    $headers[] = 'From: ' . $_POST['nom'] . ' <' . $_POST['email'] . '>';
    //  $headers[] = 'Cc: Jeanne Doe <jeannedoe@gmail.com>';
    var_dump($headers);

    $sujet = $_POST['sujet'];
    $message = '<p>' . str_replace(PHP_EOL, "<br>", $_POST['message']) . '</p>';
    // str_replace(ce que je veux remplacer, par quoi, dans quelle chaine)

    mail('admin@free.fr', $sujet, $message, implode(PHP_EOL, $headers));

    // implode transforme un tableau en chaine caractères avec un séparateur entre chaque élément du tableau
    //   ligne 1 PHP_EOL ligne 2 PHP_EOL ligne 3
    // implode(séparateur, tableau)

    $chaine = "2021-02-15";
    $tab = explode('-',$chaine); // transforme une chaine en tableau en utilisant le séparateur spécifié entre chaque élément 
    // tab[0] => année
    // tab[1] => mois

}
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulaire de contact</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">

</head>

<body>

    <div class="container">
        <div class="row">
            <div class="col">



                <h1 class="text-center">Formulaire de contact</h1>
                <hr>
                <form method="post">
                    <!-- .form-group*3>label+input.form-control -->
                    <div class="form-group">
                        <label for="nom">Nom</label>
                        <input type="text" class="form-control" id="nom" name="nom">
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" id="email" name="email">
                    </div>
                    <div class="form-group">
                        <label for="sujet">Sujet</label>
                        <input type="text" class="form-control" id="sujet" name="sujet">
                    </div>
                    <div class="form-group">
                        <label for="message">Message</label>
                        <textarea name="message" id="message" cols="30" rows="10" class="form-control"></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary">Envoyer</button>

                </form>
            </div>
        </div>
    </div>


</body>

</html>